

from .models import *
from django.contrib import admin

# Register your models here.
#admin.site.register(Zone)
#admin.site.register(MonthlyTimes)
admin.site.register(ParsedTimes)
admin.site.register(ParsedZone)
admin.site.register(EsolatZone)
#admin.site.register(MasterSchedules)