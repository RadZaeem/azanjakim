from django.apps import AppConfig


class AzanlocatorConfig(AppConfig):
    name = 'azanlocator'
